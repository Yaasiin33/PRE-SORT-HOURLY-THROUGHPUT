# Presort Throughput Tracker

A one-page tracker for hour-by-hour presort throughput across two platforms and their combined total, measured against per-hour targets. It runs in any browser with nothing to install and no account or server.

Default targets per hour:

| | Target |
|---|---|
| Platform 1 | 9,500 |
| Platform 2 | 4,500 |
| Total (P1 + P2) | 14,000 |

You can change them with **Edit targets**.

## What it shows

- **Day cards** for Total, Platform 1 and Platform 2. Each shows the volume so far against the target for the hours entered, how many hours hit target, the best hour, and a 24-hour strip of hits and misses.
- **Shipments per hour**: P1 and P2 stacked, with the total and P1 target lines and a status dot over each hour.
- **Hour by hour**: one row per hour of the sort day (03:00 to 02:00). Type P1 and P2 and the total and the difference from target fill themselves in. The current hour is highlighted.

Status colours:

- **▲ green**: at or above target
- **● amber**: within 10% under target
- **▼ red**: more than 10% under target
- A blank hour isn't judged.

The **Mono** switch removes the status colours. The arrows and dots still show hits and misses. The page follows the device's light or dark setting.

## How the data is kept

- Figures save in the browser you type them in (localStorage), as soon as you leave each box. They stay on that device and browser and aren't sent anywhere.
- **Copy share link for this day** builds a link that carries that day's figures and targets in the part after the `#`. Anyone who opens it sees the same numbers, read-only, and can save a copy to their own tracker.
- **Download backup** saves every day and your targets as a JSON file. **Restore backup** loads one, for example on another device.
- A private or incognito window doesn't keep figures after it closes, so download a backup first.

## Publish it on GitHub Pages

1. On GitHub, create a new **public** repository, for example `presort-throughput-tracker`.
2. Choose **Add file → Upload files**, drag in `index.html`, `styles.css`, `app.js`, `README.md` and `LICENSE`, then **Commit changes**.
3. Go to **Settings → Pages**. Under **Build and deployment**, set **Source** to *Deploy from a branch*, choose `main` and `/ (root)`, then **Save**.
4. After a minute or two the page is live at `https://<your-username>.github.io/presort-throughput-tracker/`. Anyone with that link can use it.

To run it locally instead, open `index.html` in a browser.

## Files

| File | What it is |
|---|---|
| `index.html` | Page structure |
| `styles.css` | Look and both themes |
| `app.js` | Saving, share links, backups, chart and table |

Fonts load from Google Fonts. If they can't load, the page falls back to system fonts.

## Licence

MIT. See [LICENSE](LICENSE).
