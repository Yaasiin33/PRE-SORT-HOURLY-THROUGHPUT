(function () {
  "use strict";
  const HOURS = ["03","04","05","06","07","08","09","10","11","12","13","14","15","16","17","18","19","20","21","22","23","00","01","02"];
  const DEFAULT_TARGETS = { p1: 9500, p2: 4500, total: 14000 };
  const STORE_KEY = "presort-throughput-tracker-v1";
  const fmt = n => n == null ? "—" : Math.round(n).toLocaleString("en-GB");
  const sgn = n => (n > 0 ? "+" : n < 0 ? "−" : "±") + Math.abs(Math.round(n)).toLocaleString("en-GB");
  const num = v => (typeof v === "number" && isFinite(v) && v >= 0) ? v : null;

  const state = { days: {}, targets: { ...DEFAULT_TARGETS }, date: null, shared: null, canSave: true };

  // ---------- storage (this browser only) ----------
  function load() {
    try {
      const raw = localStorage.getItem(STORE_KEY);
      if (!raw) return;
      const d = JSON.parse(raw);
      if (d && typeof d === "object") {
        state.days = cleanDays(d.days);
        state.targets = cleanTargets(d.targets);
      }
    } catch (e) { state.canSave = false; }
  }
  function persist() {
    try { localStorage.setItem(STORE_KEY, JSON.stringify({ days: state.days, targets: state.targets })); return true; }
    catch (e) { state.canSave = false; return false; }
  }
  function cleanTargets(t) {
    t = t || {};
    return { p1: num(t.p1) || DEFAULT_TARGETS.p1, p2: num(t.p2) || DEFAULT_TARGETS.p2, total: num(t.total) || DEFAULT_TARGETS.total };
  }
  function cleanDays(days) {
    const out = {};
    if (!days || typeof days !== "object") return out;
    Object.keys(days).forEach(k => {
      if (!/^\d{4}-\d{2}-\d{2}$/.test(k)) return;
      const d = days[k] || {}, day = { p1: {}, p2: {} };
      ["p1", "p2"].forEach(p => HOURS.forEach(h => { const v = num(d[p] && d[p][h]); if (v != null) day[p][h] = v; }));
      if (typeof d.updatedAt === "string") day.updatedAt = d.updatedAt;
      out[k] = day;
    });
    return out;
  }

  // ---------- share links: #v1;date;p1t,p2t,tt;24 p1 values;24 p2 values ----------
  function encodeShare(key) {
    const d = state.days[key] || { p1: {}, p2: {} }, T = state.targets;
    const row = p => HOURS.map(h => d[p] && d[p][h] != null ? d[p][h] : "").join(",");
    return "v1;" + key + ";" + [T.p1, T.p2, T.total].join(",") + ";" + row("p1") + ";" + row("p2");
  }
  function decodeShare(hash) {
    const parts = decodeURIComponent(hash.replace(/^#/, "")).split(";");
    if (parts.length !== 5 || parts[0] !== "v1" || !/^\d{4}-\d{2}-\d{2}$/.test(parts[1])) return null;
    const t = parts[2].split(",").map(Number);
    const col = s => { const a = s.split(","), o = {}; if (a.length !== 24) return null; a.forEach((v, i) => { if (v !== "") { const n = num(Number(v)); if (n != null) o[HOURS[i]] = n; } }); return o; };
    const p1 = col(parts[3]), p2 = col(parts[4]);
    if (!p1 || !p2) return null;
    return { date: parts[1], p1, p2, targets: cleanTargets({ p1: t[0], p2: t[1], total: t[2] }) };
  }

  // ---------- dates ----------
  const iso = d => d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
  function sortDayKey(d) { const x = new Date(d.getTime()); if (x.getHours() < 3) x.setDate(x.getDate() - 1); return iso(x); }
  function shiftDay(key, n) { const [y, m, d] = key.split("-").map(Number); const x = new Date(y, m - 1, d); x.setDate(x.getDate() + n); return iso(x); }
  function niceDate(key) { const [y, m, d] = key.split("-").map(Number); return new Date(y, m - 1, d).toLocaleDateString("en-GB", { weekday: "short", day: "numeric", month: "short", year: "numeric" }); }
  function currentHourIndex() { const now = new Date(); return sortDayKey(now) === state.date ? HOURS.indexOf(String(now.getHours()).padStart(2, "0")) : -1; }

  // ---------- status ----------
  function status(v, t) { if (v == null || !t) return "none"; if (v >= t) return "ok"; if (v >= t * 0.9) return "near"; return "bad"; }
  const glyph = { ok: "▲", near: "●", bad: "▼", none: "" };
  const viewing = () => state.shared && state.shared.date === state.date;
  const targets = () => viewing() ? state.shared.targets : state.targets;
  function dayData(key) {
    const d = viewing() ? state.shared : (state.days[key] || {});
    const p1 = d.p1 || {}, p2 = d.p2 || {};
    return HOURS.map(h => {
      const a = num(p1[h]), b = num(p2[h]);
      return { h, p1: a, p2: b, total: (a == null && b == null) ? null : (a || 0) + (b || 0) };
    });
  }

  // ---------- small DOM helpers ----------
  const $ = id => document.getElementById(id);
  function div(c) { const d = document.createElement("div"); d.className = c; return d; }
  function span(c, t) { const s = document.createElement("span"); s.className = c; s.textContent = t; return s; }
  let connTimer;
  function setConn(text, warn) {
    const c = $("conn"); c.className = warn ? "warn" : "live";
    const dot = document.createElement("span"); dot.className = "dot";
    c.replaceChildren(dot, text);
    clearTimeout(connTimer);
    if (warn) connTimer = setTimeout(() => setConn(state.canSave ? "Saved in this browser" : "This browser won't keep figures (private window?)", !state.canSave), 5000);
  }

  // ---------- tiles ----------
  function tile(el, label, key, rows, target) {
    const vals = rows.map(r => r[key]), counted = vals.filter(v => v != null);
    const sum = counted.reduce((s, v) => s + v, 0), tgt = counted.length * target;
    const st = counted.length ? status(sum, tgt) : "none";
    const pct = tgt ? Math.round(sum / tgt * 100) : null;
    const hits = counted.filter(v => v >= target).length;
    const best = counted.length ? Math.max(...counted) : null;
    const bestH = best != null ? rows[vals.indexOf(best)].h + ":00" : "";
    const r1 = div("row"); r1.append(span("k", label), span("pill " + st, st === "none" ? "No data" : glyph[st] + " " + pct + "% of target"));
    const big = div("big"); big.textContent = fmt(counted.length ? sum : null);
    const sub = div("sub"); sub.textContent = counted.length ? "vs " + fmt(tgt) + " for " + counted.length + " h  ·  " + sgn(sum - tgt) : "Target " + fmt(target) + " per hour";
    const sub2 = div("sub"); sub2.textContent = counted.length ? hits + " of " + counted.length + " hours hit " + fmt(target) + "  ·  best " + fmt(best) + " at " + bestH : "Nothing entered for this day yet";
    const hb = div("hitbar"); hb.setAttribute("aria-hidden", "true");
    vals.forEach(v => { const i = document.createElement("i"); const s = status(v, target); if (s !== "none") i.className = s; hb.append(i); });
    el.replaceChildren(r1, big, sub, sub2, hb);
  }

  // ---------- chart ----------
  const chartEl = $("chart");
  const tip = document.createElement("div"); tip.className = "tip"; tip.hidden = true;
  function drawChart(rows) {
    const T = targets();
    const W = Math.max(300, chartEl.clientWidth || 800), H = W < 560 ? 220 : 280;
    const m = { t: 22, r: 8, b: 26, l: 44 }, iw = W - m.l - m.r, ih = H - m.t - m.b;
    const maxV = Math.max(T.total * 1.15, ...rows.map(r => r.total || 0));
    const step = maxV > 30000 ? 10000 : maxV > 12000 ? 5000 : 2500;
    const top = Math.ceil(maxV / step) * step;
    const y = v => m.t + ih - (v / top) * ih, bw = iw / HOURS.length;
    const ns = "http://www.w3.org/2000/svg", svg = document.createElementNS(ns, "svg");
    svg.setAttribute("viewBox", "0 0 " + W + " " + H);
    svg.setAttribute("role", "img");
    svg.setAttribute("aria-label", "Stacked hourly shipments for P1 and P2 against the hourly targets");
    const STYLE = { fill: 1, stroke: 1, "stroke-width": 1, "stroke-dasharray": 1, opacity: 1, "font-size": 1, "font-family": 1, "font-weight": 1 };
    const el = (tag, attrs, text) => {
      const e = document.createElementNS(ns, tag);
      for (const k in attrs) {
        if (STYLE[k]) e.style.setProperty(k, k === "font-size" ? attrs[k] + "px" : String(attrs[k]));
        else e.setAttribute(k, attrs[k]);
      }
      if (text != null) e.textContent = text;
      svg.append(e); return e;
    };
    for (let v = 0; v <= top; v += step) {
      el("line", { x1: m.l, x2: W - m.r, y1: y(v), y2: y(v), stroke: "var(--line)", "stroke-width": 1 });
      el("text", { x: m.l - 6, y: y(v) + 4, "text-anchor": "end", fill: "var(--muted)", "font-size": 10.5, "font-family": "var(--font-num)" }, v ? (v / 1000) + "k" : "0");
    }
    const cur = currentHourIndex(), every = W < 560 ? 3 : (W < 820 ? 2 : 1);
    rows.forEach((r, i) => {
      const x = m.l + i * bw, w = Math.max(2, bw * 0.68), xo = x + (bw - w) / 2;
      if (i === cur) el("rect", { x, y: m.t, width: bw, height: ih, fill: "var(--ink)", opacity: 0.05 });
      const a = r.p1 || 0, b = r.p2 || 0;
      if (a) el("rect", { x: xo, y: y(a), width: w, height: y(0) - y(a), fill: "var(--bar1)", rx: 1.5 });
      if (b) el("rect", { x: xo, y: y(a + b), width: w, height: y(a) - y(a + b), fill: "var(--bar2)", rx: 1.5 });
      const st = status(r.total, T.total);
      if (st !== "none") el("circle", { cx: x + bw / 2, cy: Math.min(y(r.total), y(T.total)) - 8, r: W < 560 ? 2.6 : 3.4, fill: "var(--" + st + ")" });
      if (i % every === 0) el("text", { x: x + bw / 2, y: H - 8, "text-anchor": "middle", fill: "var(--muted)", "font-size": 10.5, "font-family": "var(--font-num)" }, r.h);
      el("rect", { x, y: m.t, width: bw, height: ih, fill: "transparent", "data-i": i });
    });
    el("line", { x1: m.l, x2: W - m.r, y1: y(T.total), y2: y(T.total), stroke: "var(--ink)", "stroke-width": 1.5, "stroke-dasharray": "5 4" });
    el("line", { x1: m.l, x2: W - m.r, y1: y(T.p1), y2: y(T.p1), stroke: "var(--muted)", "stroke-width": 1, "stroke-dasharray": "2 4" });
    el("text", { x: W - m.r, y: y(T.total) - 5, "text-anchor": "end", fill: "var(--ink)", "font-size": 10.5, "font-weight": 600, "font-family": "var(--font-num)" }, fmt(T.total));
    el("text", { x: W - m.r, y: y(T.p1) - 5, "text-anchor": "end", fill: "var(--muted)", "font-size": 10.5, "font-family": "var(--font-num)" }, fmt(T.p1));
    svg.addEventListener("pointermove", e => {
      const t = e.target.closest("rect[data-i]"); if (!t) { tip.hidden = true; return; }
      const r = rows[+t.getAttribute("data-i")], box = chartEl.getBoundingClientRect();
      const head = document.createElement("b"); head.textContent = r.h + ":00";
      tip.replaceChildren(head, document.createElement("br"), "P1 " + fmt(r.p1) + "  ·  P2 " + fmt(r.p2), document.createElement("br"),
        "Total " + fmt(r.total) + (r.total != null ? "  (" + sgn(r.total - T.total) + ")" : ""));
      tip.hidden = false;
      const tw = tip.offsetWidth, px = e.clientX - box.left, py = e.clientY - box.top;
      tip.style.left = Math.min(Math.max(px, tw / 2 + 4), box.width - tw / 2 - 4) + "px";
      tip.style.top = Math.max(py - 10, tip.offsetHeight + 4) + "px";
    });
    svg.addEventListener("pointerleave", () => { tip.hidden = true; });
    chartEl.replaceChildren(svg, tip);
  }

  // ---------- ledger ----------
  function buildRows() {
    const tbody = $("rows"); tbody.replaceChildren();
    HOURS.forEach((h, i) => {
      const tr = document.createElement("tr"); tr.id = "row-" + h;
      const th = document.createElement("td"); th.className = "hr"; th.append(h + ":00");
      const sm = document.createElement("small"); sm.textContent = "to " + HOURS[(i + 1) % 24] + ":00"; th.append(sm); tr.append(th);
      ["p1", "p2"].forEach(p => {
        const td = document.createElement("td"), c = div("cell"); c.id = "c-" + p + "-" + h;
        const inp = document.createElement("input");
        inp.type = "text"; inp.inputMode = "numeric"; inp.id = "in-" + p + "-" + h; inp.placeholder = "—";
        inp.setAttribute("aria-label", p.toUpperCase() + " shipments " + h + ":00");
        inp.addEventListener("change", () => commit(p, h, inp));
        inp.addEventListener("keydown", e => { if (e.key === "Enter") inp.blur(); });
        const d = span("delta none", ""); d.id = "d-" + p + "-" + h;
        c.append(inp, d); td.append(c); tr.append(td);
      });
      const td = document.createElement("td"), c = div("cell"); c.id = "c-t-" + h;
      const tot = span("tot", "—"); tot.id = "v-t-" + h;
      const d = span("delta none", ""); d.id = "d-t-" + h;
      c.append(tot, d); td.append(c); tr.append(td);
      tbody.append(tr);
    });
  }
  function paintCell(p, h, v, t) {
    const st = status(v, t);
    $("c-" + p + "-" + h).className = "cell " + (st === "none" ? "" : st);
    const d = $("d-" + p + "-" + h); d.className = "delta " + st;
    d.textContent = v == null ? "" : glyph[st] + " " + sgn(v - t);
  }
  function paintRows(rows) {
    const T = targets(), cur = currentHourIndex(), ro = viewing();
    rows.forEach((r, i) => {
      $("row-" + r.h).classList.toggle("now", i === cur);
      [["p1", T.p1], ["p2", T.p2]].forEach(([p, t]) => {
        const inp = $("in-" + p + "-" + r.h);
        if (document.activeElement !== inp) inp.value = r[p] == null ? "" : r[p].toLocaleString("en-GB");
        inp.readOnly = ro;
        paintCell(p, r.h, r[p], t);
      });
      $("v-t-" + r.h).textContent = fmt(r.total);
      paintCell("t", r.h, r.total, T.total);
    });
  }

  // ---------- render ----------
  function render() {
    const rows = dayData(state.date), T = targets();
    $("dayTitle").textContent = niceDate(state.date);
    $("date").value = state.date;
    $("thP1").textContent = "target " + fmt(T.p1) + "/h";
    $("thP2").textContent = "target " + fmt(T.p2) + "/h";
    $("thT").textContent = "target " + fmt(T.total) + "/h";
    $("lgTotal").textContent = "Total target " + fmt(T.total);
    $("lgP1").textContent = "P1 target " + fmt(T.p1);
    tile($("tile-total"), "Total · P1 + P2", "total", rows, T.total);
    tile($("tile-p1"), "Platform 1", "p1", rows, T.p1);
    tile($("tile-p2"), "Platform 2", "p2", rows, T.p2);
    drawChart(rows);
    paintRows(rows);
    const v = viewing();
    $("sharedBanner").hidden = !v;
    if (v) $("sharedText").textContent = "Shared figures for " + niceDate(state.shared.date) + ". They aren't in your tracker until you save them.";
    $("editTargets").hidden = v;
    const d = state.days[state.date];
    $("updated").textContent = !v && d && d.updatedAt ? "Last change " + new Date(d.updatedAt).toLocaleString("en-GB", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }) : "";
    $("shareOut").hidden = true;
    resetClear();
  }

  // ---------- entering figures ----------
  function parse(txt) {
    const s = String(txt).replace(/[,\s]/g, "");
    if (s === "") return null;
    const k = /k$/i.test(s), n = Number(k ? s.slice(0, -1) : s) * (k ? 1000 : 1);
    return isFinite(n) && n >= 0 ? Math.round(n) : NaN;
  }
  function commit(p, h, inp) {
    if (viewing()) return;
    const v = parse(inp.value);
    if (Number.isNaN(v)) { inp.value = ""; setConn("Numbers only, for example 9500 or 9.5k", true); render(); return; }
    const day = state.days[state.date] = state.days[state.date] || { p1: {}, p2: {} };
    if (v == null) delete day[p][h]; else day[p][h] = v;
    day.updatedAt = new Date().toISOString();
    if (!Object.keys(day.p1).length && !Object.keys(day.p2).length) delete state.days[state.date];
    if (!persist()) setConn("This browser won't keep figures (private window?). Download a backup before closing.", true);
    render();
  }

  // ---------- shared view ----------
  function readHash() {
    if (location.hash.length < 3) { state.shared = null; return; }
    const s = decodeShare(location.hash);
    if (!s) { state.shared = null; setConn("That share link couldn't be read", true); return; }
    state.shared = s; state.date = s.date;
  }
  function clearHash() { try { history.replaceState(null, "", location.pathname + location.search); } catch (e) { location.hash = ""; } }
  $("keepShared").addEventListener("click", () => {
    const s = state.shared; if (!s) return;
    state.days[s.date] = { p1: { ...s.p1 }, p2: { ...s.p2 }, updatedAt: new Date().toISOString() };
    state.shared = null; clearHash(); persist(); render();
    setConn("Saved " + niceDate(s.date) + " to your tracker");
  });
  $("closeShared").addEventListener("click", () => { state.shared = null; clearHash(); render(); });
  window.addEventListener("hashchange", () => { readHash(); render(); });

  // ---------- share, backup, restore, clear ----------
  $("shareBtn").addEventListener("click", async () => {
    const link = location.href.split("#")[0] + "#" + (viewing() ? location.hash.slice(1) : encodeShare(state.date));
    const out = $("shareOut"); out.value = link; out.hidden = false;
    try { await navigator.clipboard.writeText(link); setConn("Share link copied"); }
    catch (e) { out.focus(); out.select(); setConn("Copy the link below", false); }
  });
  $("exportBtn").addEventListener("click", () => {
    const blob = new Blob([JSON.stringify({ app: "presort-throughput-tracker", version: 1, exportedAt: new Date().toISOString(), targets: state.targets, days: state.days }, null, 2)], { type: "application/json" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob);
    a.download = "presort-throughput-backup-" + iso(new Date()) + ".json";
    document.body.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
    setConn("Backup downloaded");
  });
  $("importFile").addEventListener("change", e => {
    const f = e.target.files && e.target.files[0]; if (!f) return;
    const r = new FileReader();
    r.onload = () => {
      try {
        const d = JSON.parse(r.result), days = cleanDays(d.days), n = Object.keys(days).length;
        if (!n) throw new Error("empty");
        Object.assign(state.days, days);
        if (d.targets) state.targets = cleanTargets(d.targets);
        persist(); render(); setConn("Restored " + n + (n === 1 ? " day" : " days") + " from the backup");
      } catch (err) { setConn("That file isn't a tracker backup", true); }
      e.target.value = "";
    };
    r.readAsText(f);
  });
  let armed = false;
  function resetClear() { armed = false; $("clearDay").textContent = "Clear this day"; }
  $("clearDay").addEventListener("click", () => {
    if (viewing() || !state.days[state.date]) { setConn("Nothing to clear for this day", true); return; }
    if (!armed) { armed = true; $("clearDay").textContent = "Click again to clear " + niceDate(state.date); return; }
    delete state.days[state.date]; persist(); render(); setConn("Cleared " + niceDate(state.date));
  });

  // ---------- targets ----------
  const form = $("tgtForm");
  function fillTargets(t) { $("tgtP1").value = t.p1; $("tgtP2").value = t.p2; $("tgtTotal").value = t.total; }
  $("editTargets").addEventListener("click", () => { fillTargets(state.targets); form.hidden = false; $("tgtP1").focus(); });
  $("tgtCancel").addEventListener("click", () => { form.hidden = true; });
  $("tgtReset").addEventListener("click", () => fillTargets(DEFAULT_TARGETS));
  form.addEventListener("submit", e => {
    e.preventDefault();
    const t = { p1: +$("tgtP1").value, p2: +$("tgtP2").value, total: +$("tgtTotal").value };
    if (![t.p1, t.p2, t.total].every(v => v > 0)) { setConn("Targets need to be above zero", true); return; }
    state.targets = t; persist(); form.hidden = true; render(); setConn("Targets saved");
  });

  // ---------- navigation and theme ----------
  function go(key) { if (viewing() && key !== state.shared.date) { state.shared = null; clearHash(); } state.date = key; render(); }
  $("prev").addEventListener("click", () => go(shiftDay(state.date, -1)));
  $("next").addEventListener("click", () => go(shiftDay(state.date, 1)));
  $("today").addEventListener("click", () => go(sortDayKey(new Date())));
  $("date").addEventListener("change", e => { if (e.target.value) go(e.target.value); });
  const app = $("app");
  function setMode(mono) {
    app.classList.toggle("mono", mono);
    $("modeMono").setAttribute("aria-pressed", String(mono));
    $("modeColour").setAttribute("aria-pressed", String(!mono));
    try { localStorage.setItem(STORE_KEY + "-mode", mono ? "mono" : "colour"); } catch (e) {}
  }
  $("modeMono").addEventListener("click", () => setMode(true));
  $("modeColour").addEventListener("click", () => setMode(false));

  let rt; window.addEventListener("resize", () => { clearTimeout(rt); rt = setTimeout(() => drawChart(dayData(state.date)), 120); });
  setInterval(() => { if (!document.activeElement || document.activeElement.tagName !== "INPUT") render(); }, 60000);

  // ---------- start ----------
  load();
  try { if (localStorage.getItem(STORE_KEY + "-mode") === "mono") setMode(true); } catch (e) {}
  state.date = sortDayKey(new Date());
  buildRows();
  readHash();
  render();
  if (!state.canSave) setConn("This browser won't keep figures (private window?)", true);
})();
